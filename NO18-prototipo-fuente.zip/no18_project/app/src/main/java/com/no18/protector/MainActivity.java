package com.no18.protector;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * NO +18 - prototype. It filters only inside its own WebView.
 * It does not install device-admin, accessibility, VPN, or uninstall-blocking controls.
 */
public class MainActivity extends Activity {
    private static final String PREFS = "no18_preferences";
    private static final String KEY_SALT = "password_salt";
    private static final String KEY_HASH = "password_hash";
    private static final String KEY_HOSTS = "blocked_hosts";
    private static final String KEY_SITE_COUNT = "site_blocks";
    private static final String KEY_AD_COUNT = "ad_blocks";
    private static final String DNS_HOST = "family-filter-dns.cleanbrowsing.org";

    private static final int BG = Color.rgb(10, 10, 13);
    private static final int PANEL = Color.rgb(27, 27, 34);
    private static final int RED = Color.rgb(239, 20, 35);
    private static final int WHITE = Color.WHITE;
    private static final int MUTED = Color.rgb(185, 185, 195);

    private final Set<String> defaultBlockedHosts = new HashSet<>(Arrays.asList(
            "pornhub.com", "xvideos.com", "xnxx.com", "redtube.com",
            "youporn.com", "tube8.com", "spankbang.com"
    ));
    private final Set<String> adHosts = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adsystem.com", "adnxs.com"
    ));

    private SharedPreferences prefs;
    private LinearLayout root;
    private WebView webView;
    private boolean browserVisible = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showAuthentication();
    }

    @Override
    public void onBackPressed() {
        if (browserVisible && webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (browserVisible) {
            browserVisible = false;
            showDashboard();
        } else {
            super.onBackPressed();
        }
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(20), dp(18), dp(18));
        setContentView(root);
    }

    private ScrollView scrollPage() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(8), 0, dp(18));
        scroll.addView(content);
        content.setTag("page_content");
        return scroll;
    }

    private LinearLayout pageContent() {
        if (root.getChildCount() > 0 && root.getChildAt(0) instanceof ScrollView) {
            ScrollView sv = (ScrollView) root.getChildAt(0);
            return (LinearLayout) sv.getChildAt(0);
        }
        return root;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private void heading(LinearLayout parent, String value) {
        TextView t = text(value, 25, WHITE, true);
        t.setPadding(0, dp(8), 0, dp(6));
        parent.addView(t);
    }

    private void note(LinearLayout parent, String value) {
        TextView t = text(value, 14, MUTED, false);
        t.setPadding(0, dp(3), 0, dp(14));
        parent.addView(t);
    }

    private GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(14));
        if (strokeColor != Color.TRANSPARENT) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(rounded(RED, Color.TRANSPARENT));
        b.setPadding(dp(12), dp(8), dp(12), dp(8));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(6), 0, dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private void addCard(LinearLayout parent, String title, String desc) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(rounded(PANEL, Color.rgb(55, 55, 65)));
        TextView h = text(title, 16, WHITE, true);
        TextView d = text(desc, 13, MUTED, false);
        d.setPadding(0, dp(5), 0, 0);
        card.addView(h);
        card.addView(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(5));
        parent.addView(card, lp);
    }

    private void showAuthentication() {
        browserVisible = false;
        setupRoot();
        ScrollView scroll = scrollPage();
        LinearLayout content = pageContent();
        TextView brand = text("⛔ NO +18", 32, RED, true);
        brand.setGravity(Gravity.CENTER);
        brand.setPadding(0, dp(32), 0, dp(8));
        content.addView(brand);
        TextView sub = text("Protector de contenido", 16, WHITE, true);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(28));
        content.addView(sub);

        boolean firstRun = prefs.getString(KEY_HASH, null) == null;
        heading(content, firstRun ? "Crear contraseña" : "Aplicación protegida");
        note(content, firstRun
                ? "Creá una contraseña de al menos 6 caracteres para abrir NO +18. Guardala en un lugar seguro."
                : "Ingresá tu contraseña para entrar. La app sigue siendo desinstalable y podés borrar sus datos desde Android.");

        EditText password = editField(firstRun ? "Nueva contraseña" : "Contraseña", true);
        content.addView(password, matchWrap());
        if (firstRun) {
            EditText confirm = editField("Repetir contraseña", true);
            content.addView(confirm, matchWrap());
            content.addView(button("Guardar contraseña", () -> {
                String p1 = password.getText().toString();
                String p2 = confirm.getText().toString();
                if (p1.length() < 6) {
                    toast("Usá al menos 6 caracteres.");
                } else if (!p1.equals(p2)) {
                    toast("Las contraseñas no coinciden.");
                } else {
                    savePassword(p1);
                    showDashboard();
                }
            }));
        } else {
            content.addView(button("Desbloquear", () -> {
                if (checkPassword(password.getText().toString())) showDashboard();
                else toast("Contraseña incorrecta.");
            }));
        }
        note(content, "Prototipo local: la contraseña protege la pantalla de esta app; no bloquea la desinstalación ni otras aplicaciones.");
    }

    private EditText editField(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextColor(WHITE);
        e.setHintTextColor(MUTED);
        e.setHint(hint);
        e.setPadding(dp(14), dp(10), dp(14), dp(10));
        e.setBackground(rounded(PANEL, Color.rgb(80, 80, 90)));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(5), 0, dp(8));
        return lp;
    }

    private void showDashboard() {
        browserVisible = false;
        setupRoot();
        scrollPage();
        LinearLayout content = pageContent();
        heading(content, "NO +18");
        note(content, "Cuidate. Controlá lo que querés ver.\nPrototipo desinstalable · versión 0.1.0");

        addCard(content, "Bloqueo dentro del navegador", "Bloquea una lista de dominios +18 y dominios publicitarios conocidos solo al navegar desde esta app.");
        addCard(content, "SafeSearch", "Las búsquedas de Google abiertas desde el navegador protegido agregan el parámetro safe=active.");
        addCard(content, "Protección más amplia", "Podés configurar DNS privado de Android para filtrar más sitios en otras apps y navegadores.");
        addCard(content, "Límite del detector", "Esta versión no tiene un detector visual con IA; no puede clasificar cualquier imagen o anuncio de todas las aplicaciones.");

        content.addView(button("Abrir navegador protegido", this::showBrowser));
        content.addView(button("Agregar sitio a bloqueados", this::addBlockedHost));
        content.addView(button("Ver / quitar sitios bloqueados", this::showBlockedHosts));
        content.addView(button("Configurar DNS privado del teléfono", this::showDnsInstructions));
        content.addView(button("Ver estadísticas", this::showStatistics));
        content.addView(button("Cambiar contraseña", this::changePassword));
        content.addView(button("Acerca del prototipo", this::showAbout));
    }

    private void showBrowser() {
        browserVisible = true;
        setupRoot();
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        TextView back = text("‹", 32, WHITE, true);
        back.setGravity(Gravity.CENTER);
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(48)));
        back.setOnClickListener(v -> { browserVisible = false; showDashboard(); });
        EditText address = editField("https://www.google.com", false);
        address.setSingleLine(true);
        toolbar.addView(address, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button go = new Button(this);
        go.setText("Ir");
        go.setTextColor(WHITE);
        go.setBackground(rounded(RED, Color.TRANSPARENT));
        toolbar.addView(go, new LinearLayout.LayoutParams(dp(58), dp(48)));
        root.addView(toolbar);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSafeBrowsingEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleNavigation(view, request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(view, Uri.parse(url));
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = normalizeHost(uri.getHost());
                if (isBlockedHost(host)) {
                    increment(KEY_SITE_COUNT);
                    return emptyResponse("text/plain", "blocked");
                }
                if (isAdHost(host)) {
                    increment(KEY_AD_COUNT);
                    return emptyResponse("text/plain", "ad-filtered");
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = text("Filtro activo solo en este navegador · no garantiza bloquear todo", 11, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);

        go.setOnClickListener(v -> loadAddress(address.getText().toString()));
        address.setOnEditorActionListener((v, actionId, event) -> {
            loadAddress(address.getText().toString());
            return true;
        });
        loadAddress("https://www.google.com/search?q=SafeSearch&safe=active");
    }

    private void loadAddress(String raw) {
        if (webView == null) return;
        String input = raw == null ? "" : raw.trim();
        if (input.isEmpty()) return;
        if (!input.matches("(?i)^https?://.*")) {
            if (input.contains(" ") || !input.contains(".")) {
                input = "https://www.google.com/search?q=" + Uri.encode(input) + "&safe=active";
            } else {
                input = "https://" + input;
            }
        }
        webView.loadUrl(input);
    }

    private boolean handleNavigation(WebView view, Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        if (!scheme.equals("http") && !scheme.equals("https")) {
            showBlockedPage(view, "Este tipo de enlace no está permitido en el navegador protegido.");
            increment(KEY_SITE_COUNT);
            return true;
        }
        String host = normalizeHost(uri.getHost());
        if (isBlockedHost(host)) {
            showBlockedPage(view, "Sitio bloqueado por NO +18. Podés revisar la lista desde la pantalla principal.");
            increment(KEY_SITE_COUNT);
            return true;
        }
        if (host.equals("google.com") || host.endsWith(".google.com")) {
            if (uri.getPath() != null && uri.getPath().startsWith("/search")
                    && !"active".equalsIgnoreCase(uri.getQueryParameter("safe"))) {
                Uri safeUri = uri.buildUpon().appendQueryParameter("safe", "active").build();
                view.loadUrl(safeUri.toString());
                return true;
            }
        }
        return false;
    }

    private void showBlockedPage(WebView view, String message) {
        String html = "<html><body style='font-family:sans-serif;background:#101014;color:white;text-align:center;padding:32px'>"
                + "<h1 style='color:#ef1423'>NO +18</h1><h2>Contenido bloqueado</h2><p>"
                + message + "</p></body></html>";
        view.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    private WebResourceResponse emptyResponse(String mime, String reason) {
        return new WebResourceResponse(mime, "UTF-8", 403, reason,
                new java.util.HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }

    private String normalizeHost(String host) {
        return host == null ? "" : host.toLowerCase(Locale.ROOT).replaceFirst("^www\\.", "");
    }

    private boolean matchesDomain(String host, String domain) {
        return !host.isEmpty() && (host.equals(domain) || host.endsWith("." + domain));
    }

    private boolean isBlockedHost(String host) {
        for (String domain : defaultBlockedHosts) if (matchesDomain(host, domain)) return true;
        for (String domain : prefs.getStringSet(KEY_HOSTS, new HashSet<>())) if (matchesDomain(host, domain)) return true;
        return false;
    }

    private boolean isAdHost(String host) {
        for (String domain : adHosts) if (matchesDomain(host, domain)) return true;
        return false;
    }

    private void addBlockedHost() {
        EditText input = editField("ejemplo.com", false);
        new AlertDialog.Builder(this)
                .setTitle("Agregar dominio bloqueado")
                .setMessage("Ingresá solo el dominio, sin https:// ni rutas.")
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Agregar", (dialog, which) -> {
                    String host = normalizeHost(input.getText().toString().trim());
                    if (host.startsWith("http://")) host = host.substring(7);
                    if (host.startsWith("https://")) host = host.substring(8);
                    if (host.contains("/")) host = host.substring(0, host.indexOf('/'));
                    if (!host.matches("(?i)[a-z0-9.-]+\\.[a-z]{2,}")) {
                        toast("Dominio no válido.");
                        return;
                    }
                    Set<String> hosts = new HashSet<>(prefs.getStringSet(KEY_HOSTS, new HashSet<>()));
                    hosts.add(host);
                    prefs.edit().putStringSet(KEY_HOSTS, hosts).apply();
                    toast("Dominio agregado.");
                }).show();
    }

    private void showBlockedHosts() {
        Set<String> custom = new HashSet<>(prefs.getStringSet(KEY_HOSTS, new HashSet<>()));
        ArrayList<String> items = new ArrayList<>();
        items.add("Incluidos por defecto: " + String.join(", ", defaultBlockedHosts));
        items.addAll(custom);
        if (custom.isEmpty()) items.add("Todavía no agregaste dominios propios.");
        String[] choices = items.toArray(new String[0]);
        new AlertDialog.Builder(this)
                .setTitle("Dominios bloqueados")
                .setItems(choices, (dialog, which) -> {
                    if (which == 0 || which >= choices.length - 1 && custom.isEmpty()) return;
                    String selected = choices[which];
                    Set<String> updated = new HashSet<>(prefs.getStringSet(KEY_HOSTS, new HashSet<>()));
                    if (updated.remove(selected)) {
                        prefs.edit().putStringSet(KEY_HOSTS, updated).apply();
                        toast("Dominio quitado.");
                    }
                })
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void showDnsInstructions() {
        new AlertDialog.Builder(this)
                .setTitle("Filtro para todo el teléfono")
                .setMessage("Este prototipo no controla el DNS automáticamente. En Android, abrí DNS privado y configurá el proveedor family-filter-dns.cleanbrowsing.org. El filtro puede bloquear muchos sitios adultos, pero no todo el contenido ni todos los anuncios. Si una conexión falla, volvé a DNS privado y elegí Automático.")
                .setNeutralButton("Copiar host DNS", (d, w) -> {
                    android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("DNS familiar", DNS_HOST));
                    toast("Host DNS copiado.");
                })
                .setPositiveButton("Abrir ajustes", (d, w) -> {
                    try {
                        startActivity(new Intent("android.settings.PRIVATE_DNS_SETTINGS"));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_SETTINGS));
                    }
                })
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void showStatistics() {
        int sites = prefs.getInt(KEY_SITE_COUNT, 0);
        int ads = prefs.getInt(KEY_AD_COUNT, 0);
        new AlertDialog.Builder(this)
                .setTitle("Estadísticas locales")
                .setMessage("Solicitudes de sitios bloqueadas: " + sites
                        + "\nSolicitudes de anuncios filtradas: " + ads
                        + "\n\nLos números cuentan bloqueos dentro del navegador de NO +18; no representan todo el teléfono.")
                .setNeutralButton("Reiniciar", (d, w) -> prefs.edit().putInt(KEY_SITE_COUNT, 0).putInt(KEY_AD_COUNT, 0).apply())
                .setPositiveButton("Cerrar", null)
                .show();
    }

    private void changePassword() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(6), dp(12), 0);
        EditText oldPass = editField("Contraseña actual", true);
        EditText newPass = editField("Nueva contraseña (mínimo 6 caracteres)", true);
        box.addView(oldPass, matchWrap());
        box.addView(newPass, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("Cambiar contraseña")
                .setView(box)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Guardar", (d, w) -> {
                    String oldValue = oldPass.getText().toString();
                    String newValue = newPass.getText().toString();
                    if (!checkPassword(oldValue)) toast("La contraseña actual no es correcta.");
                    else if (newValue.length() < 6) toast("La nueva contraseña debe tener 6 caracteres o más.");
                    else { savePassword(newValue); toast("Contraseña actualizada."); }
                }).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("Acerca de NO +18")
                .setMessage("Versión 0.1.0, prototipo desinstalable.\n\n• Bloquea dominios dentro del navegador integrado.\n• Filtra algunos dominios publicitarios conocidos en ese navegador.\n• Añade safe=active a búsquedas de Google.\n• Guarda estadísticas locales y permite una contraseña de acceso.\n\nNo analiza visualmente todas las imágenes, no filtra las demás apps y no impide la desinstalación. Para actualizar, instalá una versión nueva firmada con la misma clave de desarrollador.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void increment(String key) {
        int value = prefs.getInt(key, 0);
        prefs.edit().putInt(key, value + 1).apply();
    }

    private void savePassword(String password) {
        try {
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            byte[] hash = derive(password, salt);
            prefs.edit().putString(KEY_SALT, toHex(salt)).putString(KEY_HASH, toHex(hash)).apply();
        } catch (Exception e) {
            toast("No se pudo guardar la contraseña.");
        }
    }

    private boolean checkPassword(String password) {
        try {
            String saltText = prefs.getString(KEY_SALT, null);
            String hashText = prefs.getString(KEY_HASH, null);
            if (saltText == null || hashText == null) return false;
            byte[] expected = fromHex(hashText);
            byte[] actual = derive(password, fromHex(saltText));
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }

    private byte[] derive(String password, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 120000, 256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } finally {
            spec.clearPassword();
        }
    }

    private String toHex(byte[] bytes) {
        StringBuilder b = new StringBuilder();
        for (byte value : bytes) b.append(String.format(Locale.ROOT, "%02x", value & 0xff));
        return b.toString();
    }

    private byte[] fromHex(String value) {
        byte[] data = new byte[value.length() / 2];
        for (int i = 0; i < data.length; i++) data[i] = (byte) Integer.parseInt(value.substring(i * 2, i * 2 + 2), 16);
        return data;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
