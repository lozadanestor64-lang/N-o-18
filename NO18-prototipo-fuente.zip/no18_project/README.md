# NO +18 — prototipo Android 0.1.0

Prototipo de protección de contenido para Android, con interfaz en español y tema negro/rojo.

## Qué incluye esta versión

- Contraseña local para abrir la aplicación (mínimo 6 caracteres; se almacena como hash PBKDF2 con salt).
- Navegador integrado con una lista inicial de dominios adultos y opción de agregar dominios propios.
- Filtro básico de algunos dominios publicitarios, únicamente dentro del navegador integrado.
- SafeSearch en las búsquedas de Google realizadas desde el navegador protegido.
- Estadísticas locales de solicitudes de sitios y anuncios bloqueados.
- Acceso a los ajustes DNS privado de Android con el nombre del proveedor familiar para copiar.
- Proyecto preparado para compilarse como APK de prueba mediante GitHub Actions.

## Límites importantes

- **Es desinstalable** desde Ajustes de Android como cualquier aplicación normal. No usa permisos de administrador del dispositivo, accesibilidad ni mecanismos para impedir la desinstalación.
- La contraseña protege la pantalla de esta app; no impide que alguien borre los datos o desinstale la app. Si olvidás la contraseña, desinstalar y volver a instalar borra la configuración local.
- El bloqueo de páginas y anuncios de esta versión solo funciona dentro del navegador de NO +18. No filtra automáticamente Chrome, redes sociales, juegos u otras apps.
- No incluye un detector visual de imágenes con IA. No sería correcto afirmar que puede detectar todas las imágenes o anuncios +18. Para una protección más amplia, Android permite configurar un DNS privado familiar manualmente; tampoco es infalible.
- Las estadísticas cuentan solicitudes filtradas dentro del navegador de esta app, no todo el tráfico del teléfono.
- Las páginas web cambian; ningún listado pequeño garantiza bloquear todos los sitios adultos o anuncios.

## Compilar el APK desde GitHub (sin Android Studio en el teléfono)

1. Creá un repositorio nuevo en GitHub.
2. Subí el contenido de este ZIP manteniendo las carpetas, incluida `.github/workflows/build-apk.yml`.
3. Abrí la pestaña **Actions** del repositorio.
4. Seleccioná **Compilar APK de NO +18** y ejecutá **Run workflow** (o esperá a que termine la compilación automática luego de subir los archivos).
5. Cuando termine, abrí la ejecución y descargá el artefacto **NO18-prototipo-debug**. Dentro estará `app-debug.apk`.
6. Pasá el APK a tu Samsung e instalalo. Android puede pedir autorización para instalar desde esa fuente; hacelo solo si verificaste que el APK salió de tu propio repositorio.

## Compilar en Android Studio

- Abrí esta carpeta como proyecto en Android Studio.
- Usá JDK 17, Android SDK Platform 35 y Android Build Tools 35.0.0.
- El proyecto usa Android Gradle Plugin 8.7.3 y Gradle 8.9. Si tu Android Studio no genera el wrapper automáticamente, ejecutá `gradle wrapper --gradle-version 8.9` desde una instalación local de Gradle.
- Ejecutá **Build > Build APK(s)**. El APK de depuración queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Actualizaciones

Para conservar contraseña y lista local, una actualización debe mantener el mismo `applicationId` y estar firmada con la misma clave que la versión instalada. Los APK de depuración creados en distintos entornos pueden tener firmas diferentes; Android podría pedir desinstalar la versión anterior, lo que borra los datos locales.
